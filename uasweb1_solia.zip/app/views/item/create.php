// create.php content
