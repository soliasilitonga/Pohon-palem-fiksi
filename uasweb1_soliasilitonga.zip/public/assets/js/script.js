// script.js content
